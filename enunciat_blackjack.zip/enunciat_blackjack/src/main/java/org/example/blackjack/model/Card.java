package org.example.blackjack.model;

public class Card {
    private long id;
    private String code;
    private String image;
    private String value;
    private String suit;
    private Deck deck;

    public Card (String code, String image, String value, String suit){
        this.code=code;
        this.image = image;
        this.value = value;
        this.suit = suit;
    }
}
