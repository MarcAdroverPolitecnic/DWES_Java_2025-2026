package cat.politecnicllevant.exemples.generic.model;


public class Media {
    private String name;
    private int kbSize;
}
