package cat.politecnicllevant.exemples.generic.model;

import cat.politecnicllevant.exemples.generic.interfaces.Reproductible;

public class Audio extends Media implements Reproductible {
}
