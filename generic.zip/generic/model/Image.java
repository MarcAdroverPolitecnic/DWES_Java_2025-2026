package cat.politecnicllevant.exemples.generic.model;

public class Image extends Media{
}
