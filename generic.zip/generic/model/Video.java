package cat.politecnicllevant.exemples.generic.model;

import cat.politecnicllevant.exemples.generic.interfaces.Reproductible;

public class Video extends Media implements Reproductible {
}
