package cat.politecnicllevant.exemples.generic.interfaces;

public interface Reproductible {
}
