package org.example;

public interface Notificador {

    abstract void envia(String missatge);

    default void valida(String missatge) {
        if (missatge == null || missatge.isEmpty()){
            log("Missatge Buid");
        };
    }

    static void mostraAjuda() {
        System.out.println("Instruccions: Introdueix un missatge per a enviar. Has de triar si" +
                "enviar-ho per correu o per SMS. No enviar missatge buid");
    }

    private void log(String missatge){
        System.out.println(missatge);
    };

}
