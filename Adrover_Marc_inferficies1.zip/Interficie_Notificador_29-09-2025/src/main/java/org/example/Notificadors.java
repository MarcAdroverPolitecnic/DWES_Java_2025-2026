package org.example;

public class Notificadors {

    public static void main(String[] args) {

        EmailNotificador eN = new EmailNotificador();
        SMSNotificador smsN = new SMSNotificador();

        eN.envia("");
        eN.envia("Hola1"); //Per a fer les coses mes senzilles, he mirat si el missatge
        smsN.envia("");    // es més llarg de 20 caracters.
        smsN.envia("hola2");
        smsN.envia("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");

        Notificador.mostraAjuda();



    }
}
