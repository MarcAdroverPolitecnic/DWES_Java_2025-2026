package org.example;

public class EmailNotificador implements Notificador{


    @Override
    public void envia(String missatge) {
        valida(missatge);

        if(missatge == null || missatge.isEmpty()){
            System.out.println("Enviament per correu: missatge buid");
        } else{
            System.out.println("Enviament per correu: " + missatge);
        }

    }

}
