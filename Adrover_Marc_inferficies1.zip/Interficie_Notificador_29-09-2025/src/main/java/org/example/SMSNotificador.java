package org.example;

import java.util.Objects;

public class SMSNotificador implements Notificador{

    @Override
    public void envia(String missatge) {
        valida(missatge);

        if(missatge == null || missatge.isEmpty()){
            System.out.println("Enviament per SMS: missatge buid");
        } else if(missatge.length() > 20){
            System.out.println("Enviament per SMS: missatge massa llarg");
        } else{
            System.out.println("Enviament per SMS: " + missatge);
        }
    }

    @Override
    public void valida(String missatge) {
        if(missatge == null || missatge.isEmpty()){
            log("Missatge buid");
        } else if (missatge.length() > 20) {
            log("Missatge massa llarg");
        }
    }

    private void log(String missatge){
        System.out.println(missatge);
    }
}
