package org.example;

import lombok.Data;

@Data
public class Cotxe {
    private final String matricula;
    private final String model;
}
