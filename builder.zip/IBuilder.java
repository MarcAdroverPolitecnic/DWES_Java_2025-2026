package org.example;

public interface IBuilder {
    BankAccount build();
}
