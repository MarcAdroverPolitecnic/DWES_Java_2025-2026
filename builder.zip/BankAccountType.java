package org.example;

public enum BankAccountType {
    PLATINUM,
}
